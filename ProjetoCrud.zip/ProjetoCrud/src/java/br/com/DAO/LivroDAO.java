/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.com.DAO;

import br.com.DTO.LivroDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class LivroDAO {
    
    Connection con;
    PreparedStatement pstm;
    ResultSet rs;
    ArrayList<LivroDTO> lista = new ArrayList<>();
    
    public void CadastrarLivro(LivroDTO objLivroDTO) throws ClassNotFoundException{
         
        String sql = "insert into Livro (nome_livro) values (?)";
        con = new ConexaoDAO().conexaoBD();
        
        try {
            
            pstm = con.prepareStatement(sql);
            pstm.setString(1, objLivroDTO.getNome_Livro());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException e) {
            System.out.println("Erro...");
        }
    }
    
    public ArrayList<LivroDTO> PesquisarLivro() throws ClassNotFoundException{
        
        String sql = "select * from Livro";
        con = new ConexaoDAO().conexaoBD();
        
        try {
            
            pstm = con.prepareStatement(sql);
            rs = pstm.executeQuery(sql);
            
            while (rs.next()){
                
                LivroDTO objLivroDTO = new LivroDTO();
                objLivroDTO.setId_livro(rs.getInt("id_livro"));
                objLivroDTO.setNome_Livro(rs.getString("nome_livro"));
                
                lista.add(objLivroDTO);
                
            }
        } catch (SQLException e) {
            System.out.println("ERRO_Select");
        }
        
        return lista;
    
    }
    
    public void ExcluirLivro(LivroDTO objLivroDTO) throws ClassNotFoundException{
         
        String sql = "delete from livro where id_livro = ?";
        con = new ConexaoDAO().conexaoBD();
        
        try {
            
            pstm = con.prepareStatement(sql);
            pstm.setInt(1, objLivroDTO.getId_Livro());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException e) {
            System.out.println("Erro_Delete");
        }
    
        
    }
    
   public void AlterarLivro(LivroDTO objLivroDTO) throws ClassNotFoundException{
         
        String sql = "update livro set nome_livro  = ?  where id_livro = ?";
        con = new ConexaoDAO().conexaoBD();
        
        try {
            
            pstm = con.prepareStatement(sql);
            pstm.setString(1, objLivroDTO.getNome_Livro());
            pstm.setInt(2, objLivroDTO.getId_Livro());
            
            pstm.execute();
            pstm.close();
            
        } catch (SQLException e) {
            System.out.println("Erro_Delete");
        }
    
        
    } 
    
    
    
    
    
    
}
